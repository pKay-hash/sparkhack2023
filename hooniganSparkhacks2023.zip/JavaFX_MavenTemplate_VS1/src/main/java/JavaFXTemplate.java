
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;


public class JavaFXTemplate extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to Fitness Tracker");
		 StringProperty name = new SimpleStringProperty("");
		 IntegerProperty age = new SimpleIntegerProperty(0);
		 IntegerProperty sex = new SimpleIntegerProperty(0);
		 IntegerProperty feet = new SimpleIntegerProperty(0);
		 IntegerProperty inches = new SimpleIntegerProperty(0);
		 IntegerProperty weight = new SimpleIntegerProperty(0);
		 IntegerProperty goal = new SimpleIntegerProperty(0);
		 Member mem = new Member();
		
		 mem.pull();
		 MenuBar menuBar = new MenuBar();
		 Menu options = new Menu("Options");
		 options.setStyle("-fx-font-color: #ffffff");
		 options.setGraphic(new ImageView("file:src/main/resources/settings.png"));

		 menuBar.getMenus().add(options);
		 MenuItem exitGameMenuBar = new MenuItem("Exit");
		 options.getItems().add(exitGameMenuBar);
		 menuBar.setStyle("-fx-background-color: #26ebfc");
		 
		 Text gameTitle = new Text("TrackGuide");
		 gameTitle.setFont(Font.font("Comic Sans MS",FontWeight.BOLD, FontPosture.ITALIC,200 ));
		 gameTitle.setFill(Color.WHITE);
		 gameTitle.setStrokeWidth(3);
		 gameTitle.setStroke(Color.RED);
		 
		 
		 Button startApp = new Button("Start");
		 startApp.setPrefHeight(250);
		 startApp.setPrefWidth(550);
		 startApp.setFont(Font.font("Comic Sans MS",FontWeight.BOLD, FontPosture.ITALIC,100 ));
		 startApp.setTextFill(Color.WHITE);
		 startApp.setStyle("-fx-background-color: #000000;");
		 startApp.setOnMouseEntered(e->startApp.setStyle("-fx-background-color: #0bfc03;"));
		 startApp.setOnMouseExited(e->startApp.setStyle("-fx-background-color: #000000;"));
		 
		 Button exitGameMenu = new Button("Exit");
		 exitGameMenu.setPrefHeight(200);
		 exitGameMenu.setPrefWidth(500);
		 exitGameMenu.setFont(Font.font("Comic Sans MS",FontWeight.BOLD, FontPosture.ITALIC,85 ));
		 exitGameMenu.setTextFill(Color.WHITE);
		 exitGameMenu.setStyle("-fx-background-color: #000000;");
		 exitGameMenu.setOnMouseEntered(e->exitGameMenu.setStyle("-fx-background-color: #ff0000;"));
		 exitGameMenu.setOnMouseExited(e->exitGameMenu.setStyle("-fx-background-color: #000000;"));
		 
		 
		 Button aboutUs = new Button("About Us");
		 aboutUs.setPrefHeight(200);
		 aboutUs.setPrefWidth(500);
		 aboutUs.setFont(Font.font("Comic Sans MS",FontWeight.BOLD, FontPosture.ITALIC,70 ));
		 aboutUs.setTextFill(Color.WHITE);
		 aboutUs.setStyle("-fx-background-color: #000000;");
		 aboutUs.setOnMouseEntered(e->aboutUs.setStyle("-fx-background-color: #f5da0c;"));
		 aboutUs.setOnMouseExited(e->aboutUs.setStyle("-fx-background-color: #000000;"));
		 
		 HBox startingButtons = new HBox(15, aboutUs, startApp, exitGameMenu);
		 startingButtons.setAlignment(Pos.CENTER);
		 
		 VBox startingScreenBox = new VBox(200, gameTitle, startingButtons);
		 
	     BorderPane startingScreenBp = new BorderPane();
	     startingScreenBp.setStyle("-fx-background-color: #25286b");
	     startingScreenBp.setCenter(startingScreenBox);
	     //startingScreenBp.setTop(menuBar);
	     startingScreenBox.setAlignment(Pos.CENTER);
	     
	     Scene startScreen = new Scene(startingScreenBp, 1920, 1080);

	     Text aboutUsExplanation = new Text(
	    		 "	This app aims to make it easier for people to get in shape and stay motivated.\n\n"
	     		+"     We provide personalized workout plans, nutrition advice, and progress\n\n"
	     		+"  tracking tools. Our goal is to inspire and empower people to take control of\n\n "
	     		+"                 their health and live happier, healthier lives.");
	     aboutUsExplanation.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     aboutUsExplanation.setFill(Color.WHITE);
	     aboutUsExplanation.setStrokeWidth(0.5);
	     aboutUsExplanation.setStroke(Color.RED);
	     
	     Button continueAboutUs = new Button("Continue");
	     continueAboutUs.setPrefSize(150, 100);
		 continueAboutUs.setStyle("-fx-background-color: #2fa305");
		 continueAboutUs.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 continueAboutUs.setTextFill(Color.BLACK);
		 continueAboutUs.setOnMouseEntered(e->continueAboutUs.setStyle("-fx-background-color:  #055207"));
		 continueAboutUs.setOnMouseExited(e->continueAboutUs.setStyle("-fx-background-color: #2fa305"));
	     
		 HBox boxForContinueUs = new HBox(continueAboutUs);
		 HBox.setMargin(continueAboutUs, new Insets(0, 0, 40, 1760));
		 
		 
	     VBox aboutUsBox = new VBox(aboutUsExplanation);
	     aboutUsBox.setAlignment(Pos.CENTER);
	     BorderPane aboutUsBP = new BorderPane();
	     aboutUsBP.setCenter(aboutUsBox);
	     aboutUsBP.setBottom(boxForContinueUs);
	     
	     aboutUsBP.setStyle("-fx-background-color: #25286b");
	     Scene aboutUsScene = new Scene(aboutUsBP, 1920, 1080);
	     
	     Text promptName = new Text("Hi! What is your name?");
	     promptName.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptName.setFill(Color.WHITE);
	     promptName.setStrokeWidth(3);
	     promptName.setStroke(Color.RED);
	     
	     TextField nameInput = new TextField();
	     nameInput.setMaxHeight(100);
	     nameInput.setMaxWidth(600);
	     nameInput.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 40 ));
	     
	     
	     Button continueName = new Button("Continue");
	     continueName.setPrefSize(150, 100);
	     continueName.setStyle("-fx-background-color: #2fa305");
		 continueName.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 continueName.setTextFill(Color.BLACK);
		 continueName.setOnMouseEntered(e->continueName.setStyle("-fx-background-color:  #055207"));
		 continueName.setOnMouseExited(e->continueName.setStyle("-fx-background-color: #2fa305"));
	     continueName.setDisable(true);
		 
	     HBox boxForContinueName = new HBox(continueName);
		 HBox.setMargin(continueName, new Insets(0, 0, 40, 1760));

	     
	     VBox setupNameBox = new VBox(60, promptName, nameInput);
	     BorderPane setupNameBP = new BorderPane();
	     setupNameBox.setAlignment(Pos.CENTER);
	     setupNameBP.setCenter(setupNameBox);
	     setupNameBP.setStyle("-fx-background-color: #25286b");
	     setupNameBP.setBottom(boxForContinueName);
	     Scene setupName = new Scene(setupNameBP, 1920, 1080);
	     
	     
	     
	     Text promptAge = new Text("Hi! What is your Age?");
	     promptAge.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptAge.setFill(Color.WHITE);
	     promptAge.setStrokeWidth(3);
	     promptAge.setStroke(Color.RED);
	     
	     TextField AgeInput = new TextField();
	     AgeInput.setMaxHeight(100);
	     AgeInput.setMaxWidth(600);
	     AgeInput.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 40 ));
	     
	     
	     Button continueAge = new Button("Continue");
	     continueAge.setPrefSize(150, 100);
	     continueAge.setStyle("-fx-background-color: #2fa305");
		 continueAge.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 continueAge.setTextFill(Color.BLACK);
		 continueAge.setOnMouseEntered(e->continueAge.setStyle("-fx-background-color:  #055207"));
		 continueAge.setOnMouseExited(e->continueAge.setStyle("-fx-background-color: #2fa305"));
	     continueAge.setDisable(true);

		 
	     HBox boxForContinueAge = new HBox(continueAge);
		 HBox.setMargin(continueAge, new Insets(0, 0, 40, 1760));

	     
	     VBox setupAgeBox = new VBox(60, promptAge, AgeInput);
	     BorderPane setupAgeBP = new BorderPane();
	     setupAgeBox.setAlignment(Pos.CENTER);
	     setupAgeBP.setCenter(setupAgeBox);
	     setupAgeBP.setStyle("-fx-background-color: #25286b");
	     setupAgeBP.setBottom(boxForContinueAge);
	     Scene setupAge = new Scene(setupAgeBP, 1920, 1080);
	     
	     
	     Text promptSex = new Text("What is your Sex?");
	     promptSex.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptSex.setFill(Color.WHITE);
	     promptSex.setStrokeWidth(3);
	     promptSex.setStroke(Color.RED);
	     
	     Button male = new Button("Male");
	     male.setPrefSize(125, 75);
	     male.setStyle("-fx-background-color: #7d83bd");
		 male.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 male.setTextFill(Color.BLACK);
		 male.setOnMouseEntered(e->male.setStyle("-fx-background-color:  #0719ba"));
		 male.setOnMouseExited(e->male.setStyle("-fx-background-color: #7d83bd"));
	     Button female = new Button("Female");
	     female.setPrefSize(125, 75);
	     female.setStyle("-fx-background-color: #b57094");
		 female.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 female.setTextFill(Color.BLACK);
		 female.setOnMouseEntered(e->female.setStyle("-fx-background-color:  #ba0965"));
		 female.setOnMouseExited(e->female.setStyle("-fx-background-color: #b57094"));
	     Button other = new Button("Other");
	     other.setPrefSize(125, 75);
	     other.setStyle("-fx-background-color: #b1b56b");
		 other.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 other.setTextFill(Color.BLACK);
		 other.setOnMouseEntered(e->other.setStyle("-fx-background-color:  #b4bd08"));
		 other.setOnMouseExited(e->other.setStyle("-fx-background-color: #b1b56b"));
	     Button notPref = new Button ("N/A");
	     notPref.setPrefSize(125, 75);
	     notPref.setStyle("-fx-background-color: #5e5e5d");
		 notPref.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 notPref.setTextFill(Color.BLACK);
		 notPref.setOnMouseEntered(e->notPref.setStyle("-fx-background-color:  #ffffff"));
		 notPref.setOnMouseExited(e->notPref.setStyle("-fx-background-color: #5e5e5d"));
	     
	     
	     HBox buttonsForSex = new HBox(20, male, female, other, notPref);
	     buttonsForSex.setAlignment(Pos.CENTER);
	     
	    
	     VBox setupSexBox = new VBox(60, promptSex, buttonsForSex);
	     BorderPane setupSexBP = new BorderPane();
	     setupSexBox.setAlignment(Pos.CENTER);
	     setupSexBP.setCenter(setupSexBox);
	     setupSexBP.setStyle("-fx-background-color: #25286b");
	     Scene setupSex = new Scene(setupSexBP, 1920, 1080);
	     
	     Text promptHeight = new Text("Enter your height:");
	     promptHeight.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptHeight.setFill(Color.WHITE);
	     promptHeight.setStrokeWidth(3);
	     promptHeight.setStroke(Color.RED);
	     
	     
	     TextField feetInput = new TextField();
	     feetInput.setMaxHeight(100);
	     feetInput.setMaxWidth(600);
	     feetInput.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 40 ));
	     
	     Text feetText = new Text("ft");
	     feetText.setFont(Font.font("Comic Sans MS", FontPosture.ITALIC, 20 ));
	     feetText.setFill(Color.WHITE);
	     feetText.setStrokeWidth(3);
	     feetText.setStroke(Color.RED);
	     
	     TextField inchInput = new TextField();
	     inchInput.setMaxHeight(100);
	     inchInput.setMaxWidth(600);
	     inchInput.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 40 ));
	     
	     Text inchText = new Text("in");
	     inchText.setFont(Font.font("Comic Sans MS", FontPosture.ITALIC, 20 ));
	     inchText.setFill(Color.WHITE);
	     inchText.setStrokeWidth(3);
	     inchText.setStroke(Color.RED);
	     
	     Text promptWeight = new Text("Enter your weight:");
	     promptWeight.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptWeight.setFill(Color.WHITE);
	     promptWeight.setStrokeWidth(3);
	     promptWeight.setStroke(Color.RED);
	     
	     TextField weightInput = new TextField();
	     weightInput.setMaxHeight(100);
	     weightInput.setMaxWidth(600);
	     weightInput.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 40 ));
	     
	     Text weightText = new Text("lbs");
	     weightText.setFont(Font.font("Comic Sans MS", FontPosture.ITALIC, 20 ));
	     weightText.setFill(Color.WHITE);
	     weightText.setStrokeWidth(3);
	     weightText.setStroke(Color.RED);
	     
	   
	     
	     Button continueHeightWeight = new Button("Continue");
	     continueHeightWeight.setPrefSize(150, 100);
	     continueHeightWeight.setStyle("-fx-background-color: #2fa305");
		 continueHeightWeight.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
		 continueHeightWeight.setTextFill(Color.BLACK);
		 continueHeightWeight.setOnMouseEntered(e->continueHeightWeight.setStyle("-fx-background-color:  #055207"));
		 continueHeightWeight.setOnMouseExited(e->continueHeightWeight.setStyle("-fx-background-color: #2fa305"));
	     continueHeightWeight.setDisable(true);

		 
	     HBox feetInputs = new HBox(10, feetInput, feetText);
	     
	     HBox inchInputs = new HBox(10, inchInput, inchText);

	     HBox heightInputs = new HBox(40, feetInputs, inchInputs);
	     heightInputs.setAlignment(Pos.CENTER);
	     HBox weightInputs = new HBox(10, weightInput, weightText);
	     weightInputs.setAlignment(Pos.CENTER);
	     
	     HBox boxForContinueHeightWeight = new HBox(continueHeightWeight);
		 HBox.setMargin(continueHeightWeight, new Insets(0, 0, 40, 1760));

	     
	     VBox setupHeightWeightBox = new VBox(60, promptHeight, heightInputs, promptWeight, weightInputs);
	     BorderPane setupHeightWeightBP = new BorderPane();
	     setupHeightWeightBox.setAlignment(Pos.CENTER);
	     setupHeightWeightBP.setCenter(setupHeightWeightBox);
	     setupHeightWeightBP.setStyle("-fx-background-color: #25286b");
	     setupHeightWeightBP.setBottom(boxForContinueHeightWeight);
	     Scene setupHeightWeight = new Scene(setupHeightWeightBP, 1920, 1080);
	     
	     
	     Text promptGoal = new Text("What is your Goal?");
	     promptGoal.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, FontPosture.ITALIC, 70 ));
	     promptGoal.setFill(Color.WHITE);
	     promptGoal.setStrokeWidth(3);
	     promptGoal.setStroke(Color.RED);
	     
	     Button loseFat = new Button("Lose Fat");
	     loseFat.setPrefSize(250, 100);
	     loseFat.setStyle("-fx-background-color: #b57094");
	     loseFat.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
	     loseFat.setTextFill(Color.BLACK);
	     loseFat.setOnMouseEntered(e->loseFat.setStyle("-fx-background-color:  #ba0965"));
	     loseFat.setOnMouseExited(e->loseFat.setStyle("-fx-background-color: #b57094"));
	     
	     Button gainMuscle = new Button("Gain Muscle");
	     gainMuscle.setPrefSize(250, 100);
	     gainMuscle.setStyle("-fx-background-color: #7d83bd");
	     gainMuscle.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
	     gainMuscle.setTextFill(Color.BLACK);
	     gainMuscle.setOnMouseEntered(e->gainMuscle.setStyle("-fx-background-color:  #0719ba"));
	     gainMuscle.setOnMouseExited(e->gainMuscle.setStyle("-fx-background-color: #7d83bd"));
	     
	     Button overall = new Button("Increase Overall Functional Mobility");
	     overall.setPrefSize(500, 100);
	     overall.setStyle("-fx-background-color: #b1b56b");
	     overall.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
	     overall.setTextFill(Color.BLACK);
	     overall.setOnMouseEntered(e->overall.setStyle("-fx-background-color:  #b4bd08"));
	     overall.setOnMouseExited(e->overall.setStyle("-fx-background-color: #b1b56b"));
	    
	     
	     
	     HBox buttonsForGoal = new HBox(20, loseFat, gainMuscle, overall);
	     buttonsForGoal.setAlignment(Pos.CENTER);
	     
	    
	     VBox setupGoalBox = new VBox(60, promptGoal, buttonsForGoal);
	     BorderPane setupGoalBP = new BorderPane();
	     setupGoalBox.setAlignment(Pos.CENTER);
	     setupGoalBP.setCenter(setupGoalBox);
	     setupGoalBP.setStyle("-fx-background-color: #25286b");
	     Scene setupGoal = new Scene(setupGoalBP, 1920, 1080);
	     
	     ////
	     
	     Text mealPlanTitle = new Text("Your Plan!");
	     mealPlanTitle.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     mealPlanTitle.setFill(Color.WHITE);
	     mealPlanTitle.setStrokeWidth(0.5);
	     mealPlanTitle.setStroke(Color.RED);
	     
	     
	     Text maintenanceCalories = new Text("Maintenance Calories: ");
	     maintenanceCalories.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     maintenanceCalories.setFill(Color.ORANGE);
	     maintenanceCalories.setStrokeWidth(0.5);
	     maintenanceCalories.setStroke(Color.RED);
	     
	     Text rangeCalories = new Text("");
	     rangeCalories.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     rangeCalories.setFill(Color.ORANGE);
	     rangeCalories.setStrokeWidth(0.5);
	     rangeCalories.setStroke(Color.RED);
	     
	     Text macros = new Text("Protein: \nCarbs: \nFats: \n");
	     macros.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     macros.setFill(Color.ORANGE);
	     macros.setStrokeWidth(0.5);
	     macros.setStroke(Color.RED);
	     
	     
	     
	     Text recProteinFood = new Text("Good High-Protein Foods: ");
	     recProteinFood.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     recProteinFood.setFill(Color.ORANGE);
	     recProteinFood.setStrokeWidth(0.5);
	     recProteinFood.setStroke(Color.RED);
	     Text recCarbFood = new Text("Good High-Carb Foods: ");
	     recCarbFood.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     recCarbFood.setFill(Color.ORANGE);
	     recCarbFood.setStrokeWidth(0.5);
	     recCarbFood.setStroke(Color.RED);
	     Text recFatFood = new Text("Good High-Fat Foods: ");
	     recFatFood.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     recFatFood.setFill(Color.ORANGE);
	     recFatFood.setStrokeWidth(0.5);
	     recFatFood.setStroke(Color.RED);
	     
	     VBox mealPlan = new VBox(50, maintenanceCalories, rangeCalories, macros, recProteinFood, recCarbFood, recFatFood);
	     
	     Text exercisePlanText = new Text("Exercise Plan: ");
	     exercisePlanText.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     exercisePlanText.setFill(Color.ORANGE);
	     exercisePlanText.setStrokeWidth(0.5);
	     exercisePlanText.setStroke(Color.RED);
	     
	     Text exerciseDay1 = new Text("Day 1: ");
	     exerciseDay1.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     exerciseDay1.setFill(Color.ORANGE);
	     exerciseDay1.setStrokeWidth(0.5);
	     exerciseDay1.setStroke(Color.RED);
	     Text exerciseDay2 = new Text("Day 2: ");
	     exerciseDay2.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     exerciseDay2.setFill(Color.ORANGE);
	     exerciseDay2.setStrokeWidth(0.5);
	     exerciseDay2.setStroke(Color.RED);
	     Text exerciseDay3 = new Text("Day 3: ");
	     exerciseDay3.setFont(Font.font("Times New Roman", FontWeight.BOLD, 50));
	     exerciseDay3.setFill(Color.ORANGE);
	     exerciseDay3.setStrokeWidth(0.5);
	     exerciseDay3.setStroke(Color.RED);
	     
	     VBox exercisePlan = new VBox(20, exercisePlanText, exerciseDay1, exerciseDay2, exerciseDay3);
	     
	     HBox.setMargin(inchInputs, new Insets(0, 100, 0, 100));
	     HBox planBox = new HBox(50, mealPlan, exercisePlan);
	     
	     Button continuePlan = new Button("Continue");
	     continuePlan.setPrefSize(150, 100);
	     continuePlan.setStyle("-fx-background-color: #2fa305");
	     continuePlan.setFont(Font.font("Comic Sans MS", FontWeight.BOLD, 25));
	     continuePlan.setTextFill(Color.BLACK);
	     continuePlan.setOnMouseEntered(e->continuePlan.setStyle("-fx-background-color:  #055207"));
	     continuePlan.setOnMouseExited(e->continuePlan.setStyle("-fx-background-color: #2fa305"));
	     
		 HBox boxForContinuePlan = new HBox(continuePlan);
		 HBox.setMargin(continuePlan, new Insets(0, 0, 40, 1760));
		 
		 
	     planBox.setAlignment(Pos.CENTER);
	     BorderPane planBP = new BorderPane();
	     planBP.setCenter(planBox);
	     planBP.setBottom(boxForContinuePlan);
	     
	     planBP.setStyle("-fx-background-color: #25286b");
	     Scene planScene = new Scene(planBP, 1920, 1080);
	     ////
	     if(mem.goal == 1) {
	    	 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 
	    	 primaryStage.setScene(planScene);
			 planBP.setTop(menuBar);
			 exercisePlanText.setText("Exercise Plan (Light Weight):");
			 exerciseDay1.setText("Day 1:\n Benchpress: 3x15\n Incline Press: 3x15\n Decline Flies: 3x15\n Tricep Pulldown: 3x15");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x15\n Mid-Back Cable Rows: 3x15\n Shoulder Shrugs: 3x15\n Bicep Curls: 3x15 ");
			 exerciseDay3.setText("Day 3:\n Squats: 3x15\n Leg Press: 3x15\n Quad Extensions: 3x15\n Hamstring Curls: 3x15");
			 
			 
			 //mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint-600) + " - " + (mem.maint-250));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	     }
	     else if(mem.goal == 2) {
	    	 primaryStage.setScene(planScene);
	    	 
			 //mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint+250) + " - " + (mem.maint+600));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 exercisePlanText.setText("Exercise Plan:");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 exerciseDay1.setText("Day 1:\n Benchpress: 3x12\n Incline Press: 3x12\n Decline Flies: 3x12\n Tricep Pulldown: 3x12");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x12\n Mid-Back Cable Rows: 3x12\n Shoulder Shrugs: 3x12\n Bicep Curls: 3x12 ");
			 exerciseDay3.setText("Day 3:\n Squats: 3x12\n Leg Press: 3x12\n Quad Extensions: 3x12\n Hamstring Curls: 3x12");
	     }
	     else if (mem.goal == 3) {
	    	 
			 //mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint-300) + " - " + (mem.maint+300));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 planBP.setTop(menuBar);

			 exercisePlanText.setText("Exercise Plan (Heavy Weight):");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 exerciseDay1.setText("Day 1:\n Benchpress: 3x8\n Incline Press: 3x8\n Decline Flies: 3x8\n Tricep Pulldown: 3x8");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x8\n Mid-Back Cable Rows: 3x8\n Shoulder Shrugs: 3x8\n Bicep Curls: 3x8");
			 exerciseDay3.setText("Day 3:\n Squats: 3x15\n Leg Press: 3x8\n Quad Extensions: 3x8\n Hamstring Curls: 3x8");
	     }
	     
	     
	     
	     
	     
	     
	     exitGameMenuBar.setOnAction(e->primaryStage.close());
	     exitGameMenu.setOnAction(e->primaryStage.close());
		 aboutUs.setOnAction(e->{
			 primaryStage.setScene(aboutUsScene);
		 });
		 continueAboutUs.setOnAction(e->{
			 primaryStage.setScene(startScreen);
		 });
		 
		 startApp.setOnAction(e->{
			 primaryStage.setScene(setupName);
			 setupNameBP.setTop(menuBar);

		 });
	     continueName.setOnAction(e->{
	    	 name.set(nameInput.getText());
			 primaryStage.setScene(setupAge);
			 setupAgeBP.setTop(menuBar);
			 promptAge.setText("Hi " + name.get() + ", What is your Age?");
		 });
	     continueAge.setOnAction(e->{
	    	 age.set(Integer.valueOf(AgeInput.getText()));
			 primaryStage.setScene(setupSex);
			 setupSexBP.setTop(menuBar);
		 });	
	     
	     male.setOnAction(e->{
	    	 sex.set(1);
			 primaryStage.setScene(setupHeightWeight);
			 setupHeightWeightBP.setTop(menuBar);
		 });	
	     female.setOnAction(e->{
	    	 sex.set(2);	
			 primaryStage.setScene(setupHeightWeight);
			 setupHeightWeightBP.setTop(menuBar);
		 });	
	     other.setOnAction(e->{
	    	 sex.set(3);
			 primaryStage.setScene(setupHeightWeight);
			 setupHeightWeightBP.setTop(menuBar);
		 });	
	     notPref.setOnAction(e->{
	    	 sex.set(4);
			 primaryStage.setScene(setupHeightWeight);
			 setupHeightWeightBP.setTop(menuBar);
		 });	
	     
	     continueHeightWeight.setOnAction(e->{
	    	 feet.set(Integer.valueOf(feetInput.getText()));
	    	 inches.set(Integer.valueOf(inchInput.getText()));
	    	 weight.set(Integer.valueOf(weightInput.getText()));

			 primaryStage.setScene(setupGoal);
			 setupGoalBP.setTop(menuBar);
	     });
	     
	     loseFat.setOnAction(e->{
	    	 goal.set(1);
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 
	    	 primaryStage.setScene(planScene);
			 planBP.setTop(menuBar);
			 exercisePlanText.setText("Exercise Plan (Light Weight):");
			 exerciseDay1.setText("Day 1:\n Benchpress: 3x15\n Incline Press: 3x15\n Decline Flies: 3x15\n Tricep Pulldown: 3x15");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x15\n Mid-Back Cable Rows: 3x15\n Shoulder Shrugs: 3x15\n Bicep Curls: 3x15 ");
			 exerciseDay3.setText("Day 3:\n Squats: 3x15\n Leg Press: 3x15\n Quad Extensions: 3x15\n Hamstring Curls: 3x15");
			 mem.name = name.toString();
			 mem.age = age.get();
			 mem.feetHeight = feet.get();
			 mem.inchHeight = inches.get();
			 mem.calcHeight(mem.feetHeight, mem.inchHeight);
			 mem.weight = weight.get();
			// mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint-600) + " - " + (mem.maint-250));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
			 mem.storeIntoDB();
			 
	     });
	     gainMuscle.setOnAction(e->{
	    	 goal.set(3);
	    	 primaryStage.setScene(planScene);
	    	 mem.name = name.toString();
			 mem.age = age.get();
			 mem.feetHeight = feet.get();
			 mem.inchHeight = inches.get();
			 mem.calcHeight(mem.feetHeight, mem.inchHeight);
			 mem.weight = weight.get();
			// mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint-300) + " - " + (mem.maint+300));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 planBP.setTop(menuBar);

			 exercisePlanText.setText("Exercise Plan (Heavy Weight):");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 exerciseDay1.setText("Day 1:\n Benchpress: 3x8\n Incline Press: 3x8\n Decline Flies: 3x8\n Tricep Pulldown: 3x8");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x8\n Mid-Back Cable Rows: 3x8\n Shoulder Shrugs: 3x8\n Bicep Curls: 3x8");
			 exerciseDay3.setText("Day 3:\n Squats: 3x15\n Leg Press: 3x8\n Quad Extensions: 3x8\n Hamstring Curls: 3x8");
			 mem.storeIntoDB();

	     });
	     overall.setOnAction(e->{
	    	 goal.set(2);
	    	 primaryStage.setScene(planScene);
	    	 mem.name = name.toString();
			 mem.age = age.get();
			 mem.feetHeight = feet.get();
			 mem.inchHeight = inches.get();
			 mem.calcHeight(mem.feetHeight, mem.inchHeight);
			 mem.weight = weight.get();
			 //mem.calcBMI();
			 mem.calcMaint();
			 mem.calcTargets();
			 maintenanceCalories.setText("Maintenance Calories: "+ mem.maint);
	    	 rangeCalories.setText("Range of calories: " + (mem.maint+250) + " - " + (mem.maint+600));
	    	 macros.setText("Macros:\n Protein - " + mem.proTarget + "g Carbs - " + mem.carbTarget + "g Fats - " + mem.fatTarget+ "g");
			 exercisePlanText.setText("Exercise Plan:");
			 recProteinFood.setText("Good High-Protein Foods:\n Chicken breast, Turkey Breast,\n Lean Beef, Salmon, Shrimp");
	    	 recCarbFood.setText("Good High-Carb Foods:\n Oatmeal, Brown Rice, Quinoa,\n Sweet Potatoes, Whole Grain Bread");
	    	 recFatFood.setText("Good High-Fat Foods:\n Avocado, Fatty Fish, Nuts, Seeds");
	    	 exerciseDay1.setText("Day 1:\n Benchpress: 3x12\n Incline Press: 3x12\n Decline Flies: 3x12\n Tricep Pulldown: 3x12");
			 exerciseDay2.setText("Day 2:\n Lat Pulldown: 3x12\n Mid-Back Cable Rows: 3x12\n Shoulder Shrugs: 3x12\n Bicep Curls: 3x12 ");
			 exerciseDay3.setText("Day 3:\n Squats: 3x12\n Leg Press: 3x12\n Quad Extensions: 3x12\n Hamstring Curls: 3x12");
			 mem.storeIntoDB();
	     });
	    	 
	     continuePlan.setOnAction(e->{
	    	 
	    	 primaryStage.setScene(startScreen);
	    	 planBP.setTop(menuBar);
	     });
	     
	     
	     
	     
	     nameInput.setOnKeyTyped(e->{
	    	 if(nameInput.getText() != "") {
	    		 continueName.setDisable(false);
	    	 }
	    	 else {
	    		 continueName.setDisable(true);
	    	 }
	     });
	     
	     
	     AgeInput.setOnKeyTyped(e->{
	    	 if(AgeInput.getText() != "") {
	    		 continueAge.setDisable(false);
	    	 }
	    	 else {
	    		 continueAge.setDisable(true);
	    	 }
	     });
	     
	     weightInput.setOnKeyTyped(e->{
	    	 if((inchInput.getText() != "") && (feetInput.getText() != "") && (weightInput.getText() != "")) {
	    		 continueHeightWeight.setDisable(false);
	    	 }
	    	 else {
	    		 continueHeightWeight.setDisable(true);
	    	 }
	     });
	     feetInput.setOnKeyTyped(e->{
	    	 if((inchInput.getText() != "") && (feetInput.getText() != "") && (weightInput.getText() != "")) {
	    		 continueHeightWeight.setDisable(false);
	    	 }
	    	 else {
	    		 continueHeightWeight.setDisable(true);
	    	 }
	     });
	     inchInput.setOnKeyTyped(e->{
	    	 if((inchInput.getText() != "") && (feetInput.getText() != "") && (weightInput.getText() != "")) {
	    		 continueHeightWeight.setDisable(false);
	    	 }
	    	 else {
	    		 continueHeightWeight.setDisable(true);
	    	 }
	     });
	     
	     
	     if(mem.name == null)
	    	 primaryStage.setScene(startScreen);
	     else{
	    	 primaryStage.setScene(planScene);
		      
	     }
		 
		 primaryStage.show();
		
				
		
	}

}
