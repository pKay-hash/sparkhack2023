import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

class Member{
	
	//user info
	
	String name;
	int goal = 0;
	int age;
	int height;
	int feetHeight;
	int inchHeight;
	double BMI;
	int sex;
	int weight;
	
	//food tracking
	int maint;
	int calgoal;
	int currCalories;
	
	double proTarget;
	double carbTarget;
	double fatTarget;
	
	int currPro;
	int currCarb;
	int currFat;
	
	int liters; //for water
	
	Map<String, int[]> breakfast;
	Map<String, int[]> lunch;
	Map<String, int[]> dinner;
	Map<String, int[]> snacks;
	
	
	public Member() {
		currCalories = 0;
		breakfast = new HashMap<>();
		lunch = new HashMap<>();
		dinner = new HashMap<>();
		snacks = new HashMap<>();
		currPro = 0;
		currCarb = 0;
		currFat = 0;
	}
	public void setHeight(int feet, int inches) {
		this.feetHeight = feet;
		this.inchHeight = inches;
	}

	public void calcHeight(int feet, int inches){
		//feetHeight = feet * 12;
		this.height = feetHeight*12 + inchHeight;
	}
	public void calcBMI() {
		calcHeight(this.feetHeight, this.feetHeight);
		this.BMI = (this.weight*703)/(height*height);
		
		
	}
	
	public void calcMaint() {
		this.maint = this.weight*15;// maintenence calories
	}
	public void storeIntoDB() {
		
		 String csvFile = "src/main/resources/userdata.csv";
	        boolean append = true;

	        try {
	            FileWriter writer = new FileWriter(csvFile, append);
	            // write your data to the file here
	            String  data = toArray();
	            
	            
	            writer.write(data+"\n");
	            writer.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		

        
    }
		
	public void calcTargets() {
		if(goal == 1) {
			proTarget = 0.65*this.maint;
			carbTarget = 0.15*this.maint;
			fatTarget = 0.2*this.maint;
		}
		else if(goal == 2) {
			proTarget = 0.65*this.maint;
			carbTarget = 0.2*this.maint;
			fatTarget = 0.15*this.maint;
		}
		else {
			proTarget = 0.6*this.maint;
			carbTarget = 0.2*this.maint;
			fatTarget = 0.2*this.maint;
		}
		proTarget = proTarget/4;
		carbTarget = carbTarget/4;
		fatTarget = fatTarget/8;
	}
	public String toArray() {
		
		String data = this.name+","+ String.valueOf(this.age)+","+
		String.valueOf(this.weight)+","+ String.valueOf(this.feetHeight)+"'"+ String.valueOf(this.inchHeight)+","+ String.valueOf(this.BMI)+","+ String.valueOf(this.sex)+","+String.valueOf(this.goal);
		
		
		return data;
	}
	
	
	public void pull() {
		String csvFile = "src/main/resources/userdata.csv";
		try {
	         File file = new File(csvFile);
	         FileReader fr = new FileReader(file);
	         BufferedReader br = new BufferedReader(fr);
	         String line = "";
	         String[] tempArr;
	         line = br.readLine();
	         line = br.readLine();
	         if(line == null) {
	        	 br.close();
	        	 return;
	         }
	         tempArr = line.split(",");
	         this.name = tempArr[0];
	         this.age = Integer.valueOf(tempArr[1]);
	         this.weight = Integer.valueOf(tempArr[2]);
	         String temp = tempArr[3];
	        // System.out.println(temp);
	         this.feetHeight = Integer.valueOf(temp.substring(0,1)); 
	         //System.out.println(this.feetHeight);
	         
	         
	         this.inchHeight = Integer.valueOf(temp.substring(2, temp.length()));
	         //System.out.println(this.inchHeight);
	         
	         this.BMI = Double.valueOf(tempArr[4]);
	         this.sex = Integer.valueOf(tempArr[5]);
	         this.goal = Integer.valueOf(tempArr[6]);
	         
	         br.close();
	        } catch(IOException ioe) {
	            ioe.printStackTrace();
	         }
	}
	
	public void addFood(String meal, String food, int calories, int protein, int carbs, int fat) {
		int [] arr = {calories, protein, carbs , fat};
		this.currCarb += carbs;
		this.currPro += protein;
		this.currFat += fat;
		
		if(meal.toLowerCase() == "breakfast") {
			
			breakfast.put(food, arr);
		}
		else if(meal.toLowerCase() == "lunch") {
			
			lunch.put(food, arr);
		}
		else if(meal.toLowerCase() == "dinner") {
			
			dinner.put(food, arr);
		}
		else {
			
			snacks.put(food, arr);
		}
		
		//add calories
		
		this.currCalories+= calories;
	}
	
	public void addWater(int liters) {
		this.liters+= liters;
	}
	
	//fill in new database 
	//Day 
	public int addCal(Map<String, int[]> meal) {
		int totalCal = 0;
		
		for (String key : meal.keySet()) {
			totalCal+= meal.get(key)[0];
		}
		
		return totalCal;
		
		
	}
	public int addPro(Map<String, int[]> meal) {
		int total = 0;
		
		for (String key : meal.keySet()) {
			total+= meal.get(key)[1];
		}
		
		return total;
		
		
	}
	
	public int addCarb(Map<String, int[]> meal) {
		int total = 0;
		
		for (String key : meal.keySet()) {
			total+= meal.get(key)[2];
		}
		
		return total;
		
		
	}
	
	public int addFat(Map<String, int[]> meal) {
		int total = 0;
		
		for (String key : meal.keySet()) {
			total+= meal.get(key)[3];
		}
		
		return total;
		
		
	}
	public String Accomplishment(int goal) {
		/*
		int totalCarbs = this.addCarb(breakfast)+ this.addCarb(lunch) + this.addCarb(dinner) + this.addCarb(snacks);
		int totalPro = this.addPro(breakfast)+ this.addPro(lunch) + this.addPro(dinner) + this.addPro(snacks);
		int totalFat = this.addFat(breakfast)+ this.addFat(lunch) + this.addFat(dinner) + this.addFat(snacks);
		*/
		
		if(goal == 1) {
			if((maint-600<currCalories && currCalories <maint-250)&& (this.currCarb == this.carbTarget && this.currPro == this.proTarget && this.currFat == this.fatTarget)) {
				return "good";
			}
			else if((maint-650<currCalories && currCalories<maint-200) || (this.currCarb >= this.carbTarget || this.currPro >= this.proTarget || this.currFat >= this.fatTarget)) {
				return "okay";
			}
			else {
				return "bad";
			}
			
		}else if(goal==2) {
			if((maint-300<currCalories && currCalories<maint+300) && (this.currCarb == this.carbTarget && this.currPro == this.proTarget && this.currFat == this.fatTarget)) {
				return "good";
			}
			else if((maint-250 < currCalories && currCalories < maint+350) || (this.currCarb == this.carbTarget || this.currPro == this.proTarget || this.currFat == this.fatTarget)){
				return "okay";
			}
			else {
				return "bad";
			}
		}else {
			if((maint+250<currCalories && currCalories<maint+600)&& (this.currCarb == this.carbTarget && this.currPro == this.proTarget && this.currFat == this.fatTarget)) {
				return "good";
			}
			else if((maint+300<currCalories && currCalories<maint+650) || (this.currCarb == this.carbTarget || this.currPro == this.proTarget || this.currFat == this.fatTarget)) {
				return "okay";
			}
			else {
				return "bad";
			}
		}
	}
	
	//stores current meal macros to the DB and starts over for next day
	public void newDay() {
		String csvFile = "src/main/resources/userdata2.csv";
        boolean append = true;

        try {
            FileWriter writer = new FileWriter(csvFile, append);
            // write your data to the file here
            
            int total = addCal(breakfast)+addCal(lunch)+addCal(dinner)+addCal(snacks);
            
            writer.write(addCal(breakfast)+",");
            writer.write(addCal(lunch)+",");
            writer.write(addCal(dinner)+",");
            writer.write(addCal(snacks)+",");
            
            writer.write(total+",");
            writer.write(Accomplishment(this.goal)+"\n");
            writer.close();
            
            breakfast = new HashMap<>();
            lunch = new HashMap<>();
            dinner = new HashMap<>();
            snacks = new HashMap<>();
        } catch (IOException e) {
            e.printStackTrace();
        
		
	}
	}
	
}